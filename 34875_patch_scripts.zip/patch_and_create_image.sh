#!/bin/bash
cid=$(docker ps | grep platform-auth-service | awk '{ print $1 }')
echo "cid: $cid"

echo "Before patching.."
docker exec -it $cid /bin/bash -c -- "cat /opt/ibm/auth-service/liberty-oidc-docker/configure_ldap.sh | grep readTimeout"
docker exec -it $cid /bin/bash -c -- "ls /config/configDropins/defaults"
docker exec -it $cid /bin/bash -c -- "ls /logs"

docker cp configure_ldap.sh $cid:/opt/ibm/auth-service/liberty-oidc-docker/configure_ldap.sh
docker exec -it $cid /bin/bash -c -- "rm -rf /logs/* /config/configDropins/defaults/federated.xml /config/configDropins/defaults/ldap*.xml"

echo "After patching..ensure changes are there"
docker exec -it $cid /bin/bash -c -- "cat /opt/ibm/auth-service/liberty-oidc-docker/configure_ldap.sh | grep readTimeout"
docker exec -it $cid /bin/bash -c -- "ls /config/configDropins/defaults"
docker exec -it $cid /bin/bash -c -- "ls /logs"

docker commit -m="debug patch image" $cid ibmcom/icp-platform-auth:3.2.0-debug

echo "Restart platform-auth-service container"
docker restart $cid
