#!/bin/bash
#
# Licensed Materials - Property of IBM
# Copyright IBM Corporation 2017, 2018 All Rights Reserved.
# U.S. Government Users Restricted Rights -
# Use, duplication or disclosure restricted by GSA ADP
# IBM Corporation - initial API and implementation
#

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LDAP_CONFIG_LOG=/opt/ibm/auth-service/logs/directory_service.log
LDAP_CONFIG_BACKUP_DIR=/config/backup

LDAP_CONFIG_ENV_FILE=$1

# Define a timestamp function
timestamp() {
  date +"%Y-%m-%d_%H-%M-%S"
}

echo "[ $(timestamp) ] Configuring LDAP Registry for websphere-liberty server..." >> $LDAP_CONFIG_LOG

# source the ldap_config.env file
. $LDAP_CONFIG_ENV_FILE
echo "[ $(timestamp) ] LDAP_ID: $LDAP_ID" >> $LDAP_CONFIG_LOG

# Replace all HTML/XML special characters with their entity names
LDAP_USERFILTER=${LDAP_USERFILTER/&/&amp;}
LDAP_GROUPFILTER=${LDAP_GROUPFILTER/&/&amp;}

LDAP_USERFILTER=${LDAP_USERFILTER/</&lt;}
LDAP_GROUPFILTER=${LDAP_GROUPFILTER/</&lt;}

LDAP_USERFILTER=${LDAP_USERFILTER/>/&gt;}
LDAP_GROUPFILTER=${LDAP_GROUPFILTER/>/&gt;}

LDAP_USERFILTER=${LDAP_USERFILTER/\"/&quot;}
LDAP_GROUPFILTER=${LDAP_GROUPFILTER/\"/&quot;}

LDAP_USERFILTER=${LDAP_USERFILTER/\'/&apos;}
LDAP_GROUPFILTER=${LDAP_GROUPFILTER/\'/&apos;}

LDAP_USERFILTER=${LDAP_USERFILTER/!/&#33;}
LDAP_GROUPFILTER=${LDAP_GROUPFILTER/!/&#33;}

# Customize Filter depending on LDAP TYPE
LDAP_FILTER_TYPE='idsFilters'
if [ "$LDAP_TYPE" = 'Microsoft Active Directory' ]; then
    LDAP_FILTER_TYPE='activedFilters'
elif [ "$LDAP_TYPE" = 'IBM Tivoli Directory Server' ]; then
    LDAP_FILTER_TYPE='idsFilters'
elif [ "$LDAP_TYPE" = 'Custom' ]; then
    LDAP_FILTER_TYPE='customFilters'
elif [ "$LDAP_TYPE" = 'Sun Java System Directory Server' ]; then
    LDAP_FILTER_TYPE='iplanetFilters'
elif [ "$LDAP_TYPE" = 'Netscape Directory Server' ]; then
    LDAP_FILTER_TYPE='netscapeFilters'
elif [ "$LDAP_TYPE" = 'Microsoft Active Server' ]; then
    LDAP_FILTER_TYPE='activedFilters'
elif [ "$LDAP_TYPE" = 'IBM Lotus Domino' ]; then
    LDAP_FILTER_TYPE='domino50Filters'
elif [ "$LDAP_TYPE" = 'IBM SecureWay Directory Server' ]; then
    LDAP_FILTER_TYPE='securewayFilters'
elif [ "$LDAP_TYPE" = 'Novell eDirectory' ]; then
    LDAP_FILTER_TYPE='edirectoryFilters'
else
    LDAP_TYPE='Custom'
    LDAP_FILTER_TYPE='customFilters'
fi;

echo "[ $(timestamp) ] UPDATING /config/configDropins/defaults/ldap-$LDAP_ID.xml" >> $LDAP_CONFIG_LOG

mkdir -p $LDAP_CONFIG_BACKUP_DIR
for file in $(ls /config/configDropins/defaults/ldap-$LDAP_ID.xml 2> /dev/null); do
    mv $file $LDAP_CONFIG_BACKUP_DIR/$(basename $file).$(timestamp)
done

SSL_ENABLED='false'
if [ "$LDAP_PROTOCOL" = 'ldaps' ]; then
    SSL_ENABLED='true'

    # import ldap server certificates to liberty keystore
    $DIR/import_ldap_certs.sh
fi

LDAP_CERTIFICATE_MAP_MODE='CERTIFICATE_FILTER'
if [ -n "$LDAP_USERIDMAP" ] && [ -z "$LDAP_CERTIFICATE_FILTER" ]; then
  IFS=: read -a userIdMap <<< "$LDAP_USERIDMAP"
  LDAP_CERTIFICATE_FILTER="${userIdMap[1]}=\${SubjectCN}"
fi

# encrypt LDAP_BINDPASSWORD value
if [ -n "$LDAP_BINDPASSWORD" ]; then
  LDAP_BINDPASSWORD=$(securityUtility encode $LDAP_BINDPASSWORD)
fi

# create LDAP config file
if [ -n "$LDAP_GROUPFILTER" ] && [ -n "$LDAP_GROUPIDMAP" ] && [ -n "$LDAP_GROUPMEMBERIDMAP" ]; then
# if all group filters are non empty, create ldap config as previous, create whole file at once
echo "[ $(timestamp) ] All the group filters are configured!!" >> $LDAP_CONFIG_LOG
cat <<EOF >/config/configDropins/defaults/ldap-$LDAP_ID.xml
<server>
    <featureManager>
        <feature>ldapRegistry-3.0</feature>
    </featureManager>
    <ldapRegistry id="$LDAP_ID" realm="$LDAP_REALM" host="$LDAP_HOST" port="$LDAP_PORT" readTimeout="2m"
            ignoreCase="$LDAP_IGNORECASE" baseDN="$LDAP_BASEDN" bindDN="$LDAP_BINDDN"
            bindPassword="$LDAP_BINDPASSWORD" ldapType="$LDAP_TYPE" recursiveSearch="true" sslEnabled="$SSL_ENABLED"
            certificateMapMode="$LDAP_CERTIFICATE_MAP_MODE" certificateFilter="$LDAP_CERTIFICATE_FILTER">
        <$LDAP_FILTER_TYPE
            userFilter="$LDAP_USERFILTER"
            groupFilter="$LDAP_GROUPFILTER"
            userIdMap="$LDAP_USERIDMAP"
            groupIdMap="$LDAP_GROUPIDMAP"
            groupMemberIdMap="$LDAP_GROUPMEMBERIDMAP" />
	    <ldapCache>
	      <attributesCache size="$LDAP_ATTR_CACHE_SIZE" timeout="$LDAP_ATTR_CACHE_TIMEOUT" enabled="$LDAP_ATTR_CACHE_ENABLED" sizeLimit="$LDAP_ATTR_CACHE_SIZELIMIT"/>
	      <searchResultsCache size="$LDAP_SEARCH_CACHE_SIZE" timeout="$LDAP_SEARCH_CACHE_TIMEOUT" enabled="$LDAP_SEARCH_CACHE_ENABLED" resultsSizeLimit="$LDAP_SEARCH_CACHE_SIZELIMIT"/>
	    </ldapCache>
    </ldapRegistry>
</server>
EOF

else
# else any group filters may be empty, so create ldap config based on the group filters values
echo "[ $(timestamp) ] Any of the group filters may be not configured!!" >> $LDAP_CONFIG_LOG
LDAP_CONFIG_FILE="/config/configDropins/defaults/ldap-$LDAP_ID.xml"

echo "<server>" > $LDAP_CONFIG_FILE
echo "    <featureManager>" >> $LDAP_CONFIG_FILE
echo "        <feature>ldapRegistry-3.0</feature>" >> $LDAP_CONFIG_FILE
echo "    </featureManager>" >> $LDAP_CONFIG_FILE
echo "    <ldapRegistry id=\"$LDAP_ID\" realm=\"$LDAP_REALM\" host=\"$LDAP_HOST\" port=\"$LDAP_PORT\" readTimeout=\"2m\"" >> $LDAP_CONFIG_FILE
echo "            ignoreCase=\"$LDAP_IGNORECASE\" baseDN=\"$LDAP_BASEDN\" bindDN=\"$LDAP_BINDDN\"" >> $LDAP_CONFIG_FILE
echo "            bindPassword=\"$LDAP_BINDPASSWORD\" ldapType=\"$LDAP_TYPE\" recursiveSearch=\"true\" sslEnabled=\"$SSL_ENABLED\"" >> $LDAP_CONFIG_FILE
echo "            certificateMapMode=\"$LDAP_CERTIFICATE_MAP_MODE\" certificateFilter=\"$LDAP_CERTIFICATE_FILTER\">" >> $LDAP_CONFIG_FILE
echo "        <$LDAP_FILTER_TYPE" >> $LDAP_CONFIG_FILE
echo "            userFilter=\"$LDAP_USERFILTER\"" >> $LDAP_CONFIG_FILE

if [ -n "$LDAP_GROUPFILTER" ]; then
echo "            groupFilter=\"$LDAP_GROUPFILTER\"" >> $LDAP_CONFIG_FILE
fi

echo "            userIdMap=\"$LDAP_USERIDMAP\"" >> $LDAP_CONFIG_FILE

if [ -n "$LDAP_GROUPIDMAP" ]; then
echo "            groupIdMap=\"$LDAP_GROUPIDMAP\"" >> $LDAP_CONFIG_FILE
fi

if [ -n "$LDAP_GROUPMEMBERIDMAP" ]; then
echo "            groupMemberIdMap=\"$LDAP_GROUPMEMBERIDMAP\"" >> $LDAP_CONFIG_FILE
fi

echo "        />" >> $LDAP_CONFIG_FILE
echo "      <ldapCache>" >> $LDAP_CONFIG_FILE
echo "        <attributesCache size=\"$LDAP_ATTR_CACHE_SIZE\" timeout=\"$LDAP_ATTR_CACHE_TIMEOUT\" enabled=\"$LDAP_ATTR_CACHE_ENABLED\" sizeLimit=\"$LDAP_ATTR_CACHE_SIZELIMIT\"/>" >> $LDAP_CONFIG_FILE
echo "        <searchResultsCache size=\"$LDAP_SEARCH_CACHE_SIZE\" timeout=\"$LDAP_SEARCH_CACHE_TIMEOUT\" enabled=\"$LDAP_SEARCH_CACHE_ENABLED\" resultsSizeLimit=\"$LDAP_SEARCH_CACHE_SIZELIMIT\"/> " >> $LDAP_CONFIG_FILE
echo "      </ldapCache>" >> $LDAP_CONFIG_FILE
echo "    </ldapRegistry>" >> $LDAP_CONFIG_FILE
echo "</server>" >> $LDAP_CONFIG_FILE

fi

echo "[ $(timestamp) ] UPDATE COMPELTE: /config/configDropins/defaults/ldap-$LDAP_ID.xml" >> $LDAP_CONFIG_LOG

LDAP_FEDERATED_CONFIG_FILE="/config/configDropins/defaults/federated.xml"
echo "[ $(timestamp) ] UPDATING $LDAP_FEDERATED_CONFIG_FILE" >> $LDAP_CONFIG_LOG

if [ ! -f $LDAP_FEDERATED_CONFIG_FILE ]; then
# federated.xml file not found, so create it with all content
cat <<EOF >$LDAP_FEDERATED_CONFIG_FILE
<server>
    <featureManager>
        <feature>ldapRegistry-3.0</feature>
    </featureManager>
    <federatedRepository>
        <primaryRealm name="PrimaryRealm" allowOpIfRepoDown="true">
            <participatingBaseEntry id="pbe-$LDAP_ID" name="$LDAP_BASEDN"/>
            <participatingBaseEntry id="pbe-basic" name="o=customRealm"/>
        </primaryRealm>
    </federatedRepository>
</server>
EOF

else
# update the existing federated.xml
if ! grep -q "$LDAP_BASEDN" "$LDAP_FEDERATED_CONFIG_FILE"; then
  sed -i "/<participatingBaseEntry id=\"pbe-basic\" name=\"o=customRealm\"\/>/ i \            <participatingBaseEntry id=\"pbe-$LDAP_ID\" name=\"$LDAP_BASEDN\"\/>" $LDAP_FEDERATED_CONFIG_FILE
fi

fi

echo "[ $(timestamp) ] UPDATE COMPELTE: $LDAP_FEDERATED_CONFIG_FILE" >> $LDAP_CONFIG_LOG

# finally remove the ldap config env file
rm -f $LDAP_CONFIG_ENV_FILE

# #https://stackoverflow.com/questions/39416251/kubernetes-rest-api-create-deployment
# KUBE_TOKEN=$(</var/run/secrets/kubernetes.io/serviceaccount/token)
# KUBE_NAMESPACE=$(</var/run/secrets/kubernetes.io/serviceaccount/namespace)
# curl --cacert /var/run/secrets/kubernetes.io/serviceaccount/ca.crt \
#     -H "Authorization: Bearer $KUBE_TOKEN" \
#     https://$KUBERNETES_SERVICE_HOST:$KUBERNETES_PORT_443_TCP_PORT/api/v1/namespaces/$KUBE_NAMESPACE
